import ROOT
import sys

df=ROOT.RDataFrame("DecayTree","rootfiles/Mc_15mu_cut2_MVA.root")
df=df.Filter("(BDT>-0.03)&&(pp_ProbNNp*(1-pp_ProbNNk)*(1-pp_ProbNNpi)>0.29)&&((1-hm1_ProbNNp)*hm1_ProbNNk*(1-hm1_ProbNNpi)>0.05)&&((1-hp_ProbNNp)*hp_ProbNNk*(1-hp_ProbNNpi)>0.06)&&((1-hm2_ProbNNp)*hm2_ProbNNk*(1-hm2_ProbNNpi)>0.05)")  
df.Snapshot("DecayTree","rootfiles/MCMVA_15mu_run2_MVACut.root")
print("--"*30)

df=ROOT.RDataFrame("DecayTree","rootfiles/Data_15mu_cut2_MVA.root")
df=df.Filter("(BDT>-0.03)&&(pp_ProbNNp*(1-pp_ProbNNk)*(1-pp_ProbNNpi)>0.29)&&((1-hm1_ProbNNp)*hm1_ProbNNk*(1-hm1_ProbNNpi)>0.05)&&((1-hp_ProbNNp)*hp_ProbNNk*(1-hp_ProbNNpi)>0.06)&&((1-hm2_ProbNNp)*hm2_ProbNNk*(1-hm2_ProbNNpi)>0.05)")   
df.Snapshot("DecayTree","rootfiles/DataMVA_15mu_run2_MVACut.root")
print("--"*30)
