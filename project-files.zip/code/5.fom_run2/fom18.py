import ROOT
import numpy as np
import math

# 进度条 & 画图
from tqdm import tqdm
import matplotlib.pyplot as plt

ROOT.EnableImplicitMT()

# —— 你的数据源（保持不变）——
dfSB = ROOT.RDataFrame("DecayTree", "../rootfiles/Data_18mu_cut2_MVA.root")
dfS  = ROOT.RDataFrame("DecayTree", "../rootfiles/Mc_18mu_cut2_MVA.root")

# —— 网格（保持不变）——
BDTarray   = [-0.10, -0.09, -0.08, -0.07, -0.06, -0.05, -0.04, -0.03]
PIDparray  = [0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38]
PIDhmarray = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08]
PIDhparray = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08]

#BDTarray   = [-0.04, -0.03, -0.02, -0.01, 0.00, 0.01, 0.02, 0.03]
#PIDparray  = [0.35, 0.36, 0.37, 0.38, 0.39, 0.40, 0.41, 0.42]
#PIDhm_BEST = 0.04
#PIDhmarray = [PIDhm_BEST]
#PIDhp_BEST = 0.06
#PIDhparray = [PIDhp_BEST]


# —— 表达式（保持不变）——
pid_p   = "(pp_ProbNNp*(1-pp_ProbNNk)*(1-pp_ProbNNpi))"
pid_hm1  = "((1-hm1_ProbNNp)*hm1_ProbNNk*(1-hm1_ProbNNpi))"
pid_hp  = "((1-hp_ProbNNp)*hp_ProbNNk*(1-hp_ProbNNpi))"
pid_hm2 = "((1-hm2_ProbNNp)*hm2_ProbNNk*(1-hm2_ProbNNpi))"
#mass_win = "(abs(Xb_DTF_KmKpKm_PV_M[0]-5619.6)<120)"
mass_win = "(abs(Xb_DTF_KmKpKm_PV_M[0]-5619.6)<60)"

# —— FoM 容器（保持不变）——
FoMData = np.zeros((8,8,8,8), dtype=float)

# —— 进度条总量 —— 
total_loops = len(BDTarray)*len(PIDparray)*len(PIDhmarray)*len(PIDhparray)

with tqdm(total=total_loops, desc="Scanning FoM grid", ncols=80) as pbar:
    for i, thr_bdt in enumerate(BDTarray):
        sBDT = f"(BDT>{thr_bdt:.3f})"
        for j, thr_p in enumerate(PIDparray):
            sPID_p = f"({pid_p}>{thr_p:.3f})"
            for k, thr_hm in enumerate(PIDhmarray):
                sPID_hm1 = f"({pid_hm1}>{thr_hm:.3f})"
                sPID_hm2 = f"({pid_hm2}>{thr_hm:.3f})"
                for m, thr_hp in enumerate(PIDhparray):
                    sPID_hp = f"({pid_hp}>{thr_hp:.3f})"
                    cut_full = f"{sBDT}&&{sPID_p}&&{sPID_hm1}&&{sPID_hm2}&&{sPID_hp}"
                    Ns = dfS.Filter(cut_full).Count().GetValue()
                    Nsb = dfSB.Filter(cut_full).Filter(mass_win).Count().GetValue()
                    FoMData[i,j,k,m] = 0.0 if Nsb<=0 else float(Ns)/math.sqrt(float(Nsb))
                    pbar.update(1)  # 进度+1

# —— 保存 FoM 网格 —— 
np.save("FoMData.npy", FoMData)
print("saved FoMData.npy, best =", FoMData.max())

# —— 找到 FoM 最大值位置 & 打印最佳阈值 —— 
best_flat = np.argmax(FoMData)
i, j, k, m = np.unravel_index(best_flat, FoMData.shape)
best_fom   = FoMData[i, j, k, m]
best_BDT   = BDTarray[i]
best_pPID  = PIDparray[j]
best_hmPID = PIDhmarray[k]
best_hpPID = PIDhparray[m]

print("="*60)
print(f"[BEST] FoM = {best_fom:.6f}")
print(f"       BDT  > {best_BDT:.3f}")
print(f"       pPID > {best_pPID:.3f}")
print(f"       hmPID> {best_hmPID:.3f} (hm1 & hm2)")
print(f"       hpPID> {best_hpPID:.3f}")
print("="*60)

# —— 热力图 ①：固定 hm/hp 为最佳，画 (BDT, pPID) —— 
HM1 = FoMData[:, :, k, m]  # y: BDT, x: pPID
plt.figure()
plt.imshow(HM1, origin='lower', aspect='auto')
plt.colorbar(label='FoM = S / sqrt(B)')
plt.xticks(range(len(PIDparray)), [f"{x:.2f}" for x in PIDparray], rotation=45)
plt.yticks(range(len(BDTarray)), [f"{x:.2f}" for x in BDTarray])
plt.xlabel('pPID threshold')
plt.ylabel('BDT threshold')
plt.title(f'FoM heatmap @ hm={best_hmPID:.2f}, hp={best_hpPID:.2f}')
plt.tight_layout()
plt.savefig('FoM_18mu_heatmap_bdt_vs_pPID.png', dpi=200)

# —— 热力图 ②：固定 BDT/pPID 为最佳，画 (hmPID, hpPID) —— 
HM2 = FoMData[i, j, :, :]  # y: hmPID, x: hpPID
plt.figure()
plt.imshow(HM2, origin='lower', aspect='auto')
plt.colorbar(label='FoM = S / sqrt(B)')
plt.xticks(range(len(PIDhparray)), [f"{x:.2f}" for x in PIDhparray], rotation=45)
plt.yticks(range(len(PIDhmarray)), [f"{x:.2f}" for x in PIDhmarray])
plt.xlabel('hpPID threshold')
plt.ylabel('hmPID threshold')
plt.title(f'FoM heatmap @ BDT={best_BDT:.2f}, pPID={best_pPID:.2f}')
plt.tight_layout()
plt.savefig('FoM_18mu_heatmap_hm_vs_hp.png', dpi=200)

print("Saved heatmaps: FoM_18mu_heatmap_bdt_vs_pPID.png, FoM_18mu_heatmap_hm_vs_hp.png")
