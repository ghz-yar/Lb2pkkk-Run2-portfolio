import ROOT
import sys

ROOT.EnableImplicitMT()

fin="rootfiles/"+sys.argv[1]
fout="rootfiles/"+sys.argv[-1]

def filter(fin, fout, tree="DecayTree"):
    df = ROOT.RDataFrame(tree, fin)

    print("yield total:", df.Count().GetValue())

    # === Fiducial cuts ===
    particles = ["pp", "hm1", "hp", "hm2"]

    # 逐个末态施加相同形式的两类 cut：PX–P 关系 + 角度开口
    for p in particles:
        px_expr    = f"abs({p}_PX) < 0.28*({p}_P - 1600)"
        angle_expr = (
            f"!((abs({p}_PY/{p}_PZ) < 0.02) && "
            f"(abs({p}_PX) < (460 + 0.01350*{p}_PZ)))"
        )
        df = df.Filter(f"({px_expr}) && ({angle_expr})", f"{p} 轨迹筛选")

    # 额外动量阈值（只对 hp）
    #df = df.Filter("hp_P > 9300", "hp 动量阈值")

    # 打印各 cut 的通过率
    rep = df.Report()
    rep.Print()

    print("yield fiducial:", df.Count().GetValue())

    # 输出
    df.Snapshot(tree, fout)
    print("--" * 30)

filter(fin, fout)
