#Trigger, Mass
import ROOT
import array
import sys

ROOT.EnableImplicitMT()

cutTrigger11 = "(Xb_L0HadronDecision_TOS||Xb_L0Global_TIS)&&(Xb_Hlt1TrackAllL0Decision_TOS)&&(Xb_Hlt2Topo2BodyBBDTDecision_TOS||Xb_Hlt2Topo3BodyBBDTDecision_TOS||Xb_Hlt2Topo4BodyBBDTDecision_TOS||Xb_Hlt2Topo2BodySimpleDecision_TOS||Xb_Hlt2Topo3BodySimpleDecision_TOS||Xb_Hlt2Topo4BodySimpleDecision_TOS)&&Xb_DTF_KmKpKm_PV_M[0]<6400&&Xb_DTF_KmKpKm_PV_M[0]>5000"
cutTrigger12 = "(Xb_L0HadronDecision_TOS||Xb_L0Global_TIS)&&(Xb_Hlt1TrackAllL0Decision_TOS)&&(Xb_Hlt2Topo2BodyBBDTDecision_TOS||Xb_Hlt2Topo3BodyBBDTDecision_TOS||Xb_Hlt2Topo4BodyBBDTDecision_TOS)&&Xb_DTF_KmKpKm_PV_M[0]<6400&&Xb_DTF_KmKpKm_PV_M[0]>5000"
cutTriggerR2 = "(Xb_L0HadronDecision_TOS||Xb_L0Global_TIS)&&(Xb_Hlt1TwoTrackMVADecision_TOS||Xb_Hlt1TrackMVADecision_TOS)&&(Xb_Hlt2Topo2BodyDecision_TOS||Xb_Hlt2Topo3BodyDecision_TOS||Xb_Hlt2Topo4BodyDecision_TOS)&&Xb_DTF_KmKpKm_PV_M[0]<6400&&Xb_DTF_KmKpKm_PV_M[0]>5000"

#fn="data_precut/merge5605-18Dn-Brs.root"
fn="rootfiles/"+sys.argv[1]
fo="rootfiles/"+sys.argv[-1]


cutTrigger = cutTriggerR2
if "-11" in fn: cutTrigger = cutTrigger11
if "-12" in fn: cutTrigger = cutTrigger12
cutTrigger= "("+cutTrigger+")"

def filter(fin,fout,tree="DecayTree",mc=False):
    df=ROOT.RDataFrame(tree,fin)

    print("yield total:",df.Count().GetValue())
    
    df=df.Filter(cutTrigger)
    print("yield trigger:",df.Count().GetValue())

    df.Snapshot("DecayTree",fout)
    print("--"*30)

filter(fn,fo)
