from ROOT import *
from math import sqrt,log,acos
from array import array
import sys

ROOT.EnableImplicitMT()

def getV4(ch,part,mass):
    px=getattr(ch,part+"_PX")/1000.
    py=getattr(ch,part+"_PY")/1000.
    pz=getattr(ch,part+"_PZ")/1000.
    pe=sqrt(pow(getattr(ch,part+"_P")/1000.,2)+mass*mass)
    return TLorentzVector(px,py,pz,pe)
def getV4DTF(ch,part,mass):
    px=getattr(ch,part+"_PX")/1000.
    py=getattr(ch,part+"_PY")/1000.
    pz=getattr(ch,part+"_PZ")/1000.
    #px=getattr(ch,part+"_DTF_PV_PX")/1000.
    #py=getattr(ch,part+"_DTF_PV_PY")/1000.
    #pz=getattr(ch,part+"_DTF_PV_PZ")/1000.
    pe=sqrt(px*px+py*py+pz*pz+mass*mass)
    return TLorentzVector(px,py,pz,pe)

mB,mh,mp,mk=5.61940000,0.13957018,0.93827205,0.49367700
mB,mh,mp,mk=5.7,0.13957018,0.93827205,0.49367700
mu=0.10565837

ch1=TChain("DecayTree")
fin="rootfiles/"+sys.argv[1]
ch1.Add(fin)
fout = "rootfiles/"+sys.argv[-1]
f1=TFile(fout,"recreate")
tr1=ch1.CloneTree(0)


newBrs={
        "PpKm1_pkkk" :array("d",[0.]),
        "PpKm2_pkkk" :array("d",[0.]),
        "KpKm1_pkkk" :array("d",[0.]),
        "KpKm2_pkkk" :array("d",[0.]),
        "PpKpKm1_pkkk" :array("d",[0.]),
        "PpKpKm2_pkkk" :array("d",[0.]),
}


allNewVars = newBrs.keys()
for key in allNewVars:
    tr1.Branch(key,newBrs[key],key+"/D")

###### configure batch
total=ch1.GetEntries()
imin = 0
imax = total

for ievt in range(imin,imax):
    ch1.GetEntry(ievt)

    h1p,h1k,h1h = getV4(ch1,"pp",mp),getV4(ch1,"pp",mk),getV4(ch1,"pp",mh)
    h2p,h2k,h2h,h2u = getV4(ch1,"hm1",mp),getV4(ch1,"hm1",mk),getV4(ch1,"hm1",mh),getV4(ch1,"hm1",mu)
    h3p,h3k,h3h,h3u = getV4(ch1,"hp",mp),getV4(ch1,"hp",mk),getV4(ch1,"hp",mh),getV4(ch1,"hp",mu)
    h4p,h4k,h4h,h4u = getV4(ch1,"hm2",mp),getV4(ch1,"hm2",mk),getV4(ch1,"hm2",mh),getV4(ch1,"hm2",mu)

    newBrs["PpKm1_pkkk"][0] = (h1p+h2k).M()
    newBrs["PpKm2_pkkk"][0] = (h1p+h4k).M()
    newBrs["KpKm1_pkkk"][0] = (h2k+h3k).M()
    newBrs["KpKm2_pkkk"][0] = (h3k+h4k).M()
    newBrs["PpKpKm1_pkkk"][0] = (h1p+h3k+h2k).M()
    newBrs["PpKpKm2_pkkk"][0] = (h1p+h3k+h4k).M()

    tr1.Fill()

f1.cd()
tr1.Write()