/**********************************************************************************
 * Project   : TMVA - a Root-integrated toolkit for multivariate data analysis    *
 * Package   : TMVA                                                               *
 * Exectuable: TMVAClassificationApplication                                      *
 *                                                                                *
 * This macro provides a simple example on how to use the trained classifiers     *
 * within an analysis module                                                      *
 **********************************************************************************/

#include <cstdlib>
#include <vector>
#include <iostream>
#include <map>
#include <string>

#include "TFile.h"
#include "TTree.h"
#include "TString.h"
#include "TSystem.h"
#include "TROOT.h"
#include "TChain.h"
#include "TStopwatch.h"

#if not defined(__CINT__) || defined(__MAKECINT__)
#include "TMVA/Tools.h"
#include "TMVA/Reader.h"
#include "TMVA/MethodCuts.h"
#endif

using namespace TMVA;

void TMVAClassificationApplication( int index=0) 
{   
    ROOT::EnableImplicitMT();

    for(int iiii=0;iiii<2;iiii++){
    TString af[2]={
    "../rootfiles/Data_16mu_cut2.root",
    "../rootfiles/Mc_16mu_cut2.root",
    };
    //TString input_file_name=af[index];
    TString input_file_name=af[iiii];
    TString st;
    TMVA::Tools::Instance();

    ifstream fconf("MethodConf.txt",ios::in);
    string method;
    int use;
    std::map<std::string,int> Use;
    while(true){
        fconf>>method>>use;
        if(fconf.eof()) break;
        Use[method] = use;
    }


    TMVA::Reader *reader1 = new TMVA::Reader( "!Color:!Silent" );    

    // Create and declare to reader variables, MUST same orders names and types as weights
    Float_t f_Xb_PT_log, f_Xb_ETA, f_Xb_MINIPCHI2, f_Xb_VDChisq_OWNPV_log, f_Xb_DIRA_OWNPV_acos, f_Xb_ENDVERTEX_CHI2NDOF, f_p_PT_log, f_p_MINIPChisq_log, f_p_PROBNNp, f_h_MINIPChisq_min, f_h_MINIPChisq_max, f_h_PT_min, f_h_PT_max, f_IsolationTrackChisq_log, f_IsolationPTAsym;


    reader1->AddVariable("Xb_PT_log",&f_Xb_PT_log);
    reader1->AddVariable("Xb_ETA",&f_Xb_ETA);
    reader1->AddVariable("Xb_MINIPCHI2",&f_Xb_MINIPCHI2);
    reader1->AddVariable("Xb_VDChisq_OWNPV_log",&f_Xb_VDChisq_OWNPV_log);
    reader1->AddVariable("Xb_DIRA_OWNPV_acos",&f_Xb_DIRA_OWNPV_acos);
    reader1->AddVariable("Xb_ENDVERTEX_CHI2NDOF",&f_Xb_ENDVERTEX_CHI2NDOF);
    reader1->AddVariable("p_PT_log",&f_p_PT_log);
    reader1->AddVariable("p_MINIPChisq_log",&f_p_MINIPChisq_log);
    //reader1->AddVariable("p_PROBNNp",&f_p_PROBNNp);
    reader1->AddVariable("h_MINIPChisq_min",&f_h_MINIPChisq_min);
    reader1->AddVariable("h_MINIPChisq_max",&f_h_MINIPChisq_max);
    reader1->AddVariable("h_PT_min",&f_h_PT_min);
    reader1->AddVariable("h_PT_max",&f_h_PT_max);
    reader1->AddVariable("IsolationTrackChisq_log",&f_IsolationTrackChisq_log);
    reader1->AddVariable("IsolationPTAsym",&f_IsolationPTAsym);

    // --- Book the MVA methods

    TString dir    = "dataset/weights/";
    TString prefix1 = st.Format("TMVAClassification");

    // Book method(s)
    for (std::map<std::string,int>::iterator it = Use.begin(); it != Use.end(); it++) {
        if (it->second) {
            TString methodName = TString(it->first) + TString(" method");
            TString weightfile1 = dir + prefix1 + TString("_") + TString(it->first) + TString(".weights.xml");
            reader1->BookMVA( methodName, weightfile1 ); 
        }
    }



    TFile *input = new TFile(input_file_name);
    TTree* theTree = (TTree*)input->Get("DecayTree");
    std::cout << "MVA only supports float variables??, make sure you convert::::::::" << std::endl;

    Double_t Xb_PT_log, Xb_ETA, Xb_MINIPCHI2, Xb_VDChisq_OWNPV_log, Xb_DIRA_OWNPV_acos, Xb_ENDVERTEX_CHI2NDOF, p_PT_log, p_MINIPChisq_log, p_PROBNNp, h_MINIPChisq_min, h_MINIPChisq_max, h_PT_min, h_PT_max, IsolationTrackChisq_log, IsolationPTAsym;

    theTree->SetBranchAddress("Xb_PT_log",&Xb_PT_log);
    theTree->SetBranchAddress("Xb_ETA",&Xb_ETA);
    theTree->SetBranchAddress("Xb_MINIPCHI2",&Xb_MINIPCHI2);
    theTree->SetBranchAddress("Xb_VDChisq_OWNPV_log",&Xb_VDChisq_OWNPV_log);
    theTree->SetBranchAddress("Xb_DIRA_OWNPV_acos",&Xb_DIRA_OWNPV_acos);
    theTree->SetBranchAddress("Xb_ENDVERTEX_CHI2NDOF",&Xb_ENDVERTEX_CHI2NDOF);
    theTree->SetBranchAddress("p_PT_log",&p_PT_log);
    theTree->SetBranchAddress("p_MINIPChisq_log",&p_MINIPChisq_log);
    //theTree->SetBranchAddress("p_PROBNNp",&p_PROBNNp);
    theTree->SetBranchAddress("h_MINIPChisq_min",&h_MINIPChisq_min);
    theTree->SetBranchAddress("h_MINIPChisq_max",&h_MINIPChisq_max);
    theTree->SetBranchAddress("h_PT_min",&h_PT_min);
    theTree->SetBranchAddress("h_PT_max",&h_PT_max);
    theTree->SetBranchAddress("IsolationTrackChisq_log",&IsolationTrackChisq_log);
    theTree->SetBranchAddress("IsolationPTAsym",&IsolationPTAsym);

    TString __dir = TString(input_file_name(0,input_file_name.Last('/')+1));
    TString __file = TString(input_file_name(input_file_name.Last('/')+1,input_file_name.Last('.')-input_file_name.Last('/')-1));
    cout<<"__file: "<<__file<<endl;
    __file = __file.ReplaceAll(TString(".root"),TString(""));
    TString output_file_name = __dir+__file+"_MVA.root";
    TFile *newfile = new TFile(output_file_name,"recreate");
    TTree *newtree = theTree->CloneTree(0);

    Double_t responses1[100]={0.};
    for(int i=0;i<100;i++) responses1[i]=-1000.;
    int Nused=0;
    for (std::map<std::string,int>::iterator it = Use.begin(); it != Use.end(); it++) {
        if (it->second) {
            TString tmp = it->first;
            //TString tmp = "MVA_"+it->first+"_response";
            newtree->Branch(tmp,responses1+Nused,tmp+"/D");
            Nused++;
        }
    }

    std::cout << "--- Processing: " << theTree->GetEntries() << " events" << std::endl;
    for (Long64_t ievt=0; ievt<theTree->GetEntries();ievt++) {
        if (ievt%1000 == 0) std::cout << "--- ... Processing event: " << ievt << std::endl;
        theTree->GetEntry(ievt);
        if(Xb_ENDVERTEX_CHI2NDOF>4.) continue;
        f_Xb_PT_log = Xb_PT_log;
        f_Xb_ETA = Xb_ETA;
        f_Xb_MINIPCHI2 = Xb_MINIPCHI2;
        f_Xb_VDChisq_OWNPV_log = Xb_VDChisq_OWNPV_log;
        f_Xb_DIRA_OWNPV_acos = Xb_DIRA_OWNPV_acos;
        f_Xb_ENDVERTEX_CHI2NDOF = Xb_ENDVERTEX_CHI2NDOF;
        f_p_PT_log = p_PT_log;
        f_p_MINIPChisq_log = p_MINIPChisq_log;
        //f_p_PROBNNp = p_PROBNNp;
        f_h_MINIPChisq_min = h_MINIPChisq_min;
        f_h_MINIPChisq_max = h_MINIPChisq_max;
        f_h_PT_min = h_PT_min;
        f_h_PT_max = h_PT_max;
        f_IsolationTrackChisq_log = IsolationTrackChisq_log;
        f_IsolationPTAsym = IsolationPTAsym;

        Nused=0;
        for (std::map<std::string,int>::iterator it = Use.begin(); it != Use.end(); it++) {
            if (it->second) {
                responses1[Nused] = double(reader1->EvaluateMVA(it->first+" method"));
                Nused++;
            }
        }

        newtree->Fill();
    }


    newtree->AutoSave();
    newfile->Close();
    input->Close();

    std::cout << "--- Created root file: "<<newfile->GetName()<<" containing the MVA output and a copy of input TTree" << std::endl;

    std::cout << "==> TMVAClassificationApplication is done!" << endl << std::endl;
    delete reader1;
    delete newfile;
    delete input;
}
}
