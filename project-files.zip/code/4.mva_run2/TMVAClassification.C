#include <cstdlib>
#include <iostream>
#include <map>
#include <string>

#include "TChain.h"
#include "TFile.h"
#include "TTree.h"
#include "TString.h"
#include "TObjString.h"
#include "TSystem.h"
#include "TChain.h"
#include "fstream"
#include "TROOT.h"

#include "TMVA/Factory.h"
#include "TMVA/DataLoader.h"
#include "TMVA/Tools.h"
#include "TMVA/TMVAGui.h"

// 包含 ConfigureEachMethod.C 文件
#include "res/ConfigureEachMethod.C"

void TMVAClassification(int index = 0)
{
    // Default MVA methods to be trained + tested
    std::ifstream fconf("MethodConf.txt", std::ios::in);
    if (!fconf) {
        std::cerr << "Error: configuration file not found" << std::endl;
        exit(0);
    } else {
        std::cout << "Configuration files found" << std::endl;
    }

    std::string method;
    int use;
    std::map<std::string, int> Use;
    while (fconf >> method >> use) {
        Use[method] = use;
    }

    TMVA::Tools::Instance();
    std::cout << "==> Start TMVAClassification" << std::endl;

    TChain *tsig = new TChain("DecayTree");
    tsig->Add("../rootfiles/Mc_18md_cut2.root");
    tsig->Add("../rootfiles/Mc_18mu_cut2.root");
    tsig->Add("../rootfiles/Mc_17md_cut2.root");
    tsig->Add("../rootfiles/Mc_17mu_cut2.root");
    tsig->Add("../rootfiles/Mc_16md_cut2.root");
    tsig->Add("../rootfiles/Mc_16mu_cut2.root");
    tsig->Add("../rootfiles/Mc_15md_cut2.root");
    tsig->Add("../rootfiles/Mc_15mu_cut2.root");
    std::cout << "numSig: " << tsig->GetEntries() << std::endl;

    TChain *tbkg = new TChain("DecayTree");
    tbkg->Add("../rootfiles/Data_18md_cut2.root");
    tbkg->Add("../rootfiles/Data_18mu_cut2.root");
    tbkg->Add("../rootfiles/Data_17md_cut2.root");
    tbkg->Add("../rootfiles/Data_17mu_cut2.root");
    tbkg->Add("../rootfiles/Data_16md_cut2.root");
    tbkg->Add("../rootfiles/Data_16mu_cut2.root");
    tbkg->Add("../rootfiles/Data_15md_cut2.root");
    tbkg->Add("../rootfiles/Data_15mu_cut2.root");
    std::cout << "numBkg: " << tbkg->GetEntries() << std::endl;

    TString outfileName("TMVA");
    TFile *outputFile = TFile::Open(outfileName + ".root", "RECREATE");

    TMVA::Factory *factory = new TMVA::Factory("TMVAClassification", outputFile,
                                               "!V:!Silent:Color:DrawProgressBar:Transformations=I;D;P;G,D:AnalysisType=Classification");

    TMVA::DataLoader *dataloader = new TMVA::DataLoader("dataset");

    // 创建一个映射表来保存旧名称和新名称之间的关系
    std::vector<std::pair<std::string, std::string>> variableOrder = {
        {"Xb_PT_log", "Lb_PT(log)"},
        {"Xb_ETA", "Lb_ETA"},
        {"Xb_MINIPCHI2", "Lb_IPChi2"},
        {"Xb_VDChisq_OWNPV_log", "Lb_VDChi2"},
        {"Xb_DIRA_OWNPV_acos", "Lb_cos(DIRA)"},
        {"Xb_ENDVERTEX_CHI2NDOF", "Lb_vtxChi2ndf"},
        {"p_PT_log", "p_PT(log)"},
        {"p_MINIPChisq_log", "p_IPCHI2(log)"},
        {"h_MINIPChisq_min", "h_minIPChi2"},
        {"h_MINIPChisq_max", "h_maxIPChi2"},
        {"h_PT_min", "h_minPT"},
        {"h_PT_max", "h_maxPT"},
        {"IsolationTrackChisq_log", "IsoTrkChi2(log)"},
        {"IsolationPTAsym", "PTAsy"}
    };


    for (const auto &[old_name, new_name] : variableOrder) {
        dataloader->AddVariable(old_name, 'F');
    }

    Double_t signalWeight = 1.0;
    Double_t backgroundWeight = 1.0;

    dataloader->AddSignalTree(tsig, signalWeight);
    dataloader->AddBackgroundTree(tbkg, backgroundWeight);

    TCut mycuts = "pp_P>9300&&Xb_ENDVERTEX_CHI2NDOF<4.&&Xb_MINIPCHI2<16";
    TCut mycutb = "Xb_DTF_KmKpKm_PV_M[0]>5840.&&Xb_ENDVERTEX_CHI2NDOF<4.&&Xb_MINIPCHI2<16";

    TString train_test = TString::Format("nTrain_Signal=%i:nTrain_Background=%i:SplitMode=Random:NormMode=NumEvents:!V",
                                         int(tsig->GetEntries(mycuts) * 0.5),
                                         int(tbkg->GetEntries(mycutb) * 0.5));
    dataloader->PrepareTrainingAndTestTree(mycuts, mycutb, train_test.Data());

    ConfigureEachMethod(factory, dataloader, Use);
    factory->TrainAllMethods();
    factory->TestAllMethods();
    factory->EvaluateAllMethods();

    outputFile->Close();
    std::cout << "==> Wrote root file: " << outputFile->GetName() << std::endl;
    std::cout << "==> TMVAClassification is done!" << std::endl;

    delete factory;
    delete dataloader;

    // Launch the GUI for the root macros
    if (!gROOT->IsBatch()) TMVA::TMVAGui(outfileName + ".root");
}
