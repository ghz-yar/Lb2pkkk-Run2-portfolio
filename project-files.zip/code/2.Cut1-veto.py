import ROOT
import sys

ROOT.EnableImplicitMT()

fin="rootfiles/"+sys.argv[1]
fout="rootfiles/"+sys.argv[-1]


def filter(fin,fout,tree="DecayTree"):
    df=ROOT.RDataFrame(tree,fin)

    print("yield total:",df.Count().GetValue())
    
    df=df.Filter("hp_isMuon != 1 && hm1_isMuon != 1 && hm2_isMuon != 1", "Muon veto")\
       .Filter("(KpKm1_pkkk < 3.35 || KpKm1_pkkk > 3.45) && "\
              "(KpKm2_pkkk < 3.35 || KpKm2_pkkk > 3.45) && "\
              "(KpKm1_pkkh < 3.35 || KpKm1_pkkh > 3.45) && "\
              "(KpKm2_pkkh < 3.35 || KpKm2_pkkh > 3.45)", "chi(c0)(1P) exclusion")\
       .Filter("(KmHp1_pkhh < 1.82 || KmHp1_pkhh > 1.89 || hp_ProbNNpi<0.7) && "\
              "(KmHp2_pkhh < 1.82 || KmHp2_pkhh > 1.89 || hp_ProbNNpi<0.7)", "D0 exclusion")\
       .Filter("(KpKm1_pkkk < 1.00 || KpKm1_pkkk > 1.04) && "\
              "(KpKm2_pkkk < 1.00 || KpKm2_pkkk > 1.04) && "\
              "(KpKm1_pkkh < 1.00 || KpKm1_pkkh > 1.04) && "\
              "(KpKm2_pkkh < 1.00 || KpKm2_pkkh > 1.04)", "Phi veto")\
       .Filter("(PpKpKm1_pkkk < 2.26 || PpKpKm1_pkkk > 2.31) && "\
              "(PpKpKm2_pkkk < 2.26 || PpKpKm2_pkkk > 2.31) && "\
              "(PpKpKm1_pkkh < 2.26 || PpKpKm1_pkkh > 2.31) && "\
              "(PpKpKm2_pkkh < 2.26 || PpKpKm2_pkkh > 2.31)", "Lc+ veto")
    
    rep = df.Report()
    rep.Print()

    print("yield BKGveto:",df.Count().GetValue())

    df.Snapshot("DecayTree",fout)
    print("--"*30)

filter(fin,fout)

#python3 2.Cut1-veto.py Data_Cut0_BKG_run2.root Data_Cut1_run2.root
#python3 2.Cut1-veto.py MC_Cut0_BKG_run2.root MC_Cut1_run2.root